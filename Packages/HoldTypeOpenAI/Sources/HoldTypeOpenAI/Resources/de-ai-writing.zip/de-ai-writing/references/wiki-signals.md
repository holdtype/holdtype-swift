# Portable Wiki-Derived Signals

Use this file as a compact reference for AI-text markers adapted from the Russian Wikipedia essay on generated-text signals.

Source for future updates:

- https://ru.wikipedia.org/wiki/Википедия:Признаки_сгенерированности_текста

## Scope

Use these signals for general prose, articles, posts, and commercial copy.

Do not import the Wikipedia-specific parts literally:

- broken ISBN and DOI checks
- category checks
- wikitext or Markdown mixing checks
- other wiki-markup artifacts that do not apply outside Wikipedia

The source essay itself is explicit that these are observations rather than hard rules and that AI detectors are not final arbiters. Keep the same posture here.

## High-value transferable signals

### 1. Inflated importance language

Watch for language that overstates meaning or symbolism instead of naming a fact.

Examples of suspicious patterns:

- "играет ключевую роль"
- "символизирует"
- "служит напоминанием"
- "поворотный момент"
- "неизгладимый след"

Preferred response:

- replace symbolic language with a factual effect
- if there is no factual effect in the source, downshift the claim

### 2. Surface-level analysis

Watch for broad claims that sound analytical but do not add mechanism, evidence, or edge cases.

Common shapes:

- a generic thesis followed by generic restatement
- claims about significance without showing how or for whom
- "trend commentary" that never lands on a concrete claim

Preferred response:

- ask what changed, for whom, and because of what
- keep one specific causal claim instead of three vague ones

### 3. Vague authority

Watch for claims attributed to blurry groups rather than named, checkable sources.

Examples:

- "по словам экспертов"
- "некоторые критики утверждают"
- "отраслевые отчёты показывают"

Preferred response:

- name the source
- or remove the authority wrapper and keep only what the text can defend directly

### 4. Promotional positivity

Watch for language that sounds like PR rather than writing.

Examples:

- empty praise
- exaggerated benefits
- smooth, conflict-free success narratives
- positive adjectives stacked to imply proof

Preferred response:

- strip the praise
- keep the measurable result, limitation, or tradeoff

### 5. Didactic or editorial scaffolding

Watch for AI-style framing that announces the answer instead of just giving it.

Examples:

- "ниже представлен подробный обзор"
- "в заключение"
- "по состоянию на моё последнее обновление знаний"
- refusal or disclaimer language copied from chat responses

Preferred response:

- delete meta-commentary
- start with the claim itself

### 6. Dialogue imitation

Watch for fake letters, fake empathy, and canned address to the reader.

Examples:

- "уважаемые редакторы"
- "надеюсь, это сообщение застанет вас в добром здравии"
- overly formal or templated salutation blocks

Preferred response:

- collapse the text into direct content
- remove the staged conversation unless the format genuinely requires it

### 7. Overbuilt syntax

Watch for sentences that try to sound polished by stacking structure.

Common signals:

- dangling or bloated gerund phrases
- "не только ..., но и ..."
- "это не просто ..., это ..."
- rule-of-three sequences used as fake completeness

Preferred response:

- cut the sentence into simpler clauses
- keep the part with real information

### 8. Anti-tautology synonym churn

Watch for texts that avoid repeating a word so aggressively that they start substituting prestige synonyms.

Examples:

- replacing a named subject with "ключевой игрок", "ведущий персонаж", or similar generic labels
- rotating labels to avoid repetition even when the repeated noun would be clearer

Preferred response:

- allow honest repetition of the correct noun
- prefer exact reference over decorative synonymy

### 9. Format habits that correlate with AI writing

These are weak signals on their own but useful in combination:

- too many long dashes
- listicle headings
- bullets that start with mini-headings and then a colon
- repetitive section symmetry

Preferred response:

- vary structure only where it helps comprehension
- replace formatting theatrics with clearer prose

## How to use this file

1. Use these signals as a shortlist, not a checklist.
2. Combine multiple weak signals before calling text "AI-ish."
3. Prefer concrete rewrites over abstract diagnosis.
4. When a signal is present but the sentence is still useful, soften it instead of flattening it.
