# Infostyle Filter v1.0

Use this file for landing pages and commercial page copy.

Based on information style: facts, respect for the reader, and utility. Every sentence should either inform or help the reader decide.

## Purpose

Use this as a quality filter for landing-page copy inside `de-ai-writing`.

- Scope: landing pages only
- Do not use it as a replacement for the broader anti-AI-ish rewrite rules for posts, essays, or author-voice content

## Contents

- Section A: Buzzword bans
- Section B: Landing-page bans
- Section C: Positive rules
- Validation protocol
- Number deduplication protocol

## Section A: Buzzword bans

### Automatic rejection words

```text
уникальный, инновационный, революционный, прорывной
трансформация, трансформировать, трансформирующий
эффективность, эффективный, высокоэффективный
раскрой потенциал, путь к успеху, секрет успеха
лайфхак, лайфхаки, хак, хаки
синергия, синергетический
мотивация, мотивирующий, вдохновляющий
масштабирование, масштабировать
оптимизация, оптимизировать (в общем контексте)
экосистема (вне технического контекста)
```

### Weak modifiers

Require specifics or remove them:

```text
очень, крайне, невероятно, потрясающе
просто, легко, быстро (без конкретных чисел)
всего лишь, буквально
```

### Forbidden constructs

```text
Listicle: "5 способов...", "7 шагов к...", "Топ-10...", "N вещей, которые..."
Success theater: "Что делают успешные люди...", "Привычки миллионеров..."
Pseudo-science: "Учёные доказали..." (без ссылки), "По статистике..." (без источника)
Empty promises: "Гарантированный результат", "100% работает", "Изменит вашу жизнь"
```

## Section B: Landing-page bans

| # | Pattern | Example | Replacement |
|---|---------|---------|-------------|
| 1 | Rhetorical questions | "Узнаёшь?", "Устали от...?", "Знакомо?" | Replace with a direct statement: "Это касается тех, кто..." |
| 2 | "Представь:" prompts | "Представь: открываешь дайджест..." | Replace with mechanism or scope: "Дайджест: 3 сигнала, 5 минут" |
| 3 | Intimate second person | "Сидишь за ноутбуком в 3 ночи", "Ты листаешь..." | Prefer third person: "Преподаватели обновляют материалы..." |
| 4 | Emotion diagnosis | "тревога уходит", "чувствуешь облегчение", "появляется уверенность" | Replace with a measurable result or grounded capability outcome |
| 5 | Domestic drama | "Кофе остыл", "дети спят", "за кухонным столом" | Delete unless directly relevant to the product |
| 6 | Dirty currency | "Как поход в Макдак", "как чашка кофе" | Use real price: "15 000 руб/год" |
| 7 | Life currency | "Пока закипает чайник", "один эпизод сериала" | Use real time: "5 минут" |
| 8 | Number repetition across blocks | Repeating "40 -> 5 минут" in hero, situation, value_prop, mechanism | Keep each number in one block only |
| 9 | Forced contrast | "Раньше хаос. Теперь покой." | Replace with a factual before/after |
| 10 | False empathy | "Мы понимаем...", "Мы знаем, как это..." | Delete |
| 11 | Urgency manipulation | "Только сегодня!", "Осталось 3 места!" | Use real dates or real limits, or remove |
| 12 | Vague authority | "Эксперты рекомендуют", "Профессионалы выбирают" | Name the source directly |

### Banned sentence openers

```text
Представь...
Узнаёшь?
Знакомо?
А что, если...
Устали от...
Мы понимаем...
Мы знаем...
Давай честно...
Будем откровенны...
Хватит...
Пора...
```

## Section C: Positive rules

### C1. Headlines should promise useful action or a concrete outcome

Every heading should be:

- verb + measurable result, or
- verb + concrete capability

Examples:

- Bad: "Новый уровень мониторинга"
- Good: "Снизить мониторинг с 40 до 5 минут в день"
- Good: "Запустить production-ready AI-агента за первую неделю"

### C2. Every sentence should inform or help decide

If deleting a sentence changes nothing, it is padding. Delete it.

Test: what new information does this sentence add?

### C3. Numbers should have units and sources

- Bad: "значительно снижает время"
- Good: "с 40 минут до 5 минут в день (по опросу 12 преподавателей)"

### C4. Quotes should have full attribution

- Bad: "Участник курса"
- Good: "Иван, преподаватель ML, 3 года опыта, Москва"

If the source is anonymous research, say so explicitly.

### C5. Use third person by default

Default voice:

- преподаватели
- разработчики
- пользователи

Use "вы" mainly in:

- Q&A blocks
- pricing blocks that explain what is included

Never use "ты" on a landing page.

### C6. Remove padding sentences

If two sentences say the same thing, keep the more informative one.

- Bad: "Это экономит время. Вы тратите меньше времени на рутину."
- Good: "Экономия: 35 минут в день на мониторинге."

### C7. Keep one fact per block and do not repeat numbers

Track where each number appears. If the same metric already appeared in another block, keep it only where it is most useful.

### C8. Ground qualitative value

Not every product saves time or money. Capability, identity, or community claims are allowed only when grounded by real evidence such as a quote, case, or validated outcome.

Examples:

- Bad: "Почувствуй себя настоящим разработчиком"
- Bad: "Уникальное сообщество единомышленников"
- Good: "Участники получают рабочие артефакты: Skills, MCP-серверы, промпт-пайплайны. 12 из 40 участников пилота задеплоили агента в прод за первый месяц."

## Validation protocol

1. Scan for Section A buzzwords.
   - If found, reject or rewrite.
2. Scan for Section B patterns and banned openers.
   - If found, apply the grounded replacement.
3. Check the positive rules.
   - Headlines: verb + result or verb + capability
   - Sentences: new information only
   - Numbers: units + source
   - Quotes: attribution
   - Voice: third person by default
   - Padding: removed
   - Number repetition: deduplicated
   - Qualitative claims: grounded
4. Output only when the block passes the checks.

## Number deduplication protocol

Before finalizing a landing page, build a registry such as:

```yaml
number_registry:
  "40 минут": { block: "situation", context: "текущее время мониторинга" }
  "5 минут": { block: "value_prop", context: "время после внедрения" }
  "35 минут": { block: "mechanism", context: "экономия" }
  "12 преподавателей": { block: "evidence", context: "размер выборки" }
```

Rule: each number should appear in exactly one block unless the user explicitly wants repetition for strategic reasons.
