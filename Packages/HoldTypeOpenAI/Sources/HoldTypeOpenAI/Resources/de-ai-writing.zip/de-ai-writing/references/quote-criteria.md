# Quote Criteria

Use this file for short text up to 5 sentences.

## Contents

- Total scoring
- Ten criteria
- Scoring process
- Verdict thresholds
- Quick heuristic
- False-positive mitigation
- AI pattern lexicon

## Total scoring

- Max score: 38 points
- Min score: -5 points
- Threshold: 26 or higher suggests probable slop

## Ten criteria

| # | Criterion | Max | What to check |
|---|-----------|-----|---------------|
| 1 | Zero position | 5 | Show no personal opinion or stake; give only generic advice |
| 2 | No "life dirt" | 6 | Omit what broke, where it got stuck, what it cost, or other lived details |
| 3 | No verifiability | 4 | Omit dates, versions, tools, specific names, or testable claims |
| 4 | Fake confidence | 4 | Say "always do X" without context or tradeoffs |
| 5 | Lexical repetition | 3 | Repeat stock AI phrases or canned transitions |
| 6 | Too clean logic | 3 | Avoid tension, contradiction, or self-correction |
| 7 | Weak causality | 4 | Explain with placeholders instead of actual cause-and-effect |
| 8 | No personal stake | 5 | Remove "I," "my," "we," or any author investment |
| 9 | First-hand bonus | -5 | Show real first-hand experience such as "I tried" or "my project" |
| 10 | Info density | 4 | Use many words but give few facts |

## Scoring process

1. Score each positive criterion from 0 to its max.
2. Apply the first-hand bonus only when the text shows clear real experience.
3. Sum the points.

`total_score = sum(criteria_scores) + first_hand_bonus`

## Verdict thresholds

| Score | Verdict |
|-------|---------|
| 10 or below | `clean` |
| 11-18 | `good` |
| 19-25 | `acceptable` |
| 26-38 | `probable_slop` |

## Quick heuristic

Use this before full scoring:

1. Check first person. Real "I/me/my" usually lowers suspicion.
2. Check specifics. Dates, versions, tools, prices, or named failures usually lower suspicion.
3. Check stock openers. "It's important to..." or "Важно понимать..." raises suspicion.

If the text has first-person experience, concrete specifics, and no obvious stock phrasing, skip full scoring and treat it as `good` unless the user asked for a formal score.

## False-positive mitigation

- Cap the result at `good` when the text comes from a strong technical source and includes specific technical details.
- Avoid over-penalizing expert summaries that are concise but still concrete.
- Avoid rewarding fake first-person language that does not include any lived detail.

## AI pattern lexicon

### English patterns

```text
essentially
it's important to note
in conclusion
at the end of the day
a myriad of
navigate the landscape
unlock the potential
in today's fast-paced world
game-changer
deep dive
```

### Russian patterns

```text
в конечном итоге
стоит отметить
на самом деле
важно понимать
ключевой момент
безусловно
в целом и общем
не лишним будет
нельзя не отметить
```
