# Full Slop Detection Criteria (v2.0)

Use this file for long-form articles, blog posts, and other longer prose.

## Contents

- Total scoring
- Block 1: Position and voice
- Block 2: Structure
- Block 3: Specifics
- Block 4: Credibility
- Block 5: Language
- Block 6: Logic
- Block 7: Additional criteria
- Verdict thresholds
- Quick checklist
- AI pattern lexicon
- When to use this file

## Total scoring

- Max score: 126 points
- Threshold: 50 or higher suggests probable slop

## Block 1: Position and voice

### 1. Zero author position (0-6 points)
- 0: Show a clear thesis, personal opinion, or stake
- 3: Show a position but keep it vague
- 6: Say a little about everything and commit to nothing

### 2. Too even tone (0-4 points)
- 0: Show emotion, humor, doubt, annoyance, or surprise
- 2: Show some liveliness
- 4: Read like a corporate memo

### 3. No personal accountability (0-4 points)
- 0: Use phrases such as "my stack," "my mistake," or "I would do"
- 2: Hint at experience
- 4: Give abstract advice without ownership

## Block 2: Structure

### 4. Clone paragraphs (0-5 points)
- 0: Vary structure naturally
- 3: Show partial templating
- 5: Repeat the same section rhythm throughout

### 5. Lists for lists' sake (0-4 points)
- 0: Use lists only when they help
- 2: Include some interchangeable items
- 4: Pad listicles with filler

### 6. Unnatural completeness (0-5 points)
- 0: Focus on a real slice of the problem
- 3: Go broad but keep some depth
- 5: Try to "cover everything" like a textbook summary

## Block 3: Specifics

### 7. Generic words without specifics (0-6 points)
- 0: Use numbers, examples, links, or concrete claims
- 3: Include some specifics but not many
- 6: Lean on words such as "important," "key," or "effective" without proof

### 8. No verifiability (0-7 points)
- 0: Include dates, versions, PRs, issues, commits, configs, or reproduction details
- 4: Include partial verification
- 7: Give no dates, names, versions, or reproducible details

### 9. No "life dirt" (0-5 points)
- 0: Show what broke, what surprised you, or where you got stuck
- 3: Include some process detail
- 5: Make everything look smooth and painless

### 10. No edge-cases (0-5 points)
- 0: Mention exceptions, nuance, or "but if..."
- 3: Include some caveats
- 5: Give only universal advice

## Block 4: Credibility

### 11. Links "for show" (0-5 points)
- 0: Cite RFCs, PRs, issues, commits, or specific guides
- 3: Mix useful links with broad links
- 5: Cite only general explainers or filler links

### 12. Fake confidence (0-5 points)
- 0: Scope claims with "it depends" or a concrete context
- 3: Add a few caveats
- 5: State universal rules without context

### 13. Implausible examples (0-5 points)
- 0: Use real examples with implementation detail
- 3: Include examples but not the "how"
- 5: Make dramatic claims without support

### 14. Weak cause-effect chain (0-6 points)
- 0: Show "we did A, got B, because of C"
- 3: Show some causal links
- 6: Justify with placeholders such as "because it's important"

## Block 5: Language

### 15. Lexical repetition (0-4 points)
- 0: Use varied language
- 2: Repeat some phrases
- 4: Keep reaching for stock transitions and filler wording

### 16. Pseudo-metaphors (0-3 points)
- 0: Use metaphors only when they explain
- 2: Add some decoration
- 3: Use empty comparison as ornament

### 17. Bad terminology (0-5 points)
- 0: Use terms precisely
- 3: Use terms decoratively at times
- 5: Use terms mainly as prestige markers

### 18. Sharp depth jumps (0-4 points)
- 0: Move through depth smoothly
- 2: Show some jumps
- 4: Jump between beginner and advanced depth without connection

## Block 6: Logic

### 19. Too clean logic (0-4 points)
- 0: Leave room for doubt, reversal, or self-correction
- 2: Stay mostly linear
- 4: Present perfect frictionless logic

### 20. Sterile conclusions (0-4 points)
- 0: End with specific, usable takeaways
- 2: End with partially useful takeaways
- 4: End with empty "best practices" language

## Block 7: Additional criteria

### 21. Promotional intent (0-8 points)
- 0: Avoid product pushes and CTAs
- 4: Mention the product subtly
- 8: Push product signups or self-promotion hard

### 22. Source attribution (-3 to +7 points)
- -3: Link to primary sources
- 0: Attribute normally
- +7: Make claims without backing

### 23. First-hand experience (-7 to +3 points)
- -7: Show clear real experience such as "I built" or "my project"
- 0: Stay neutral
- +3: Fake first-hand authority without specifics

### 24. Information density (0-6 points)

Use this formula:

`density = (entities + numbers + dates + citations) / words * 1000`

Base score:

| Density | Score |
|---------|-------|
| 15 or higher | 0 |
| 10-14 | 1 |
| 5-9 | 2 |
| 2-4 | 3 |
| Below 2 | 4 |

Add up to 2 extra penalty points:

- Add 0.5 for every five obvious water words such as "basically" or "essentially"
- Add 1 when a technical article has under 10% code or command content where code is expected
- Add 1 when the same idea repeats three or more times

## Verdict thresholds

| Score | Verdict |
|-------|---------|
| 0-20 | `clean` |
| 21-35 | `good` |
| 36-50 | `acceptable` |
| 51-70 | `probable_slop` |
| 71 or higher | `obvious_slop` |

## Quick checklist

Treat three or more red flags as a strong sign of slop:

- No author position or personal detail
- Repeated section pattern throughout
- Empty listicle framing such as "10 ways" or "7 steps"
- No dates, versions, or specific links
- Importance-signaling phrases without proof
- Perfect logic with no caveats, tradeoffs, or reversals
- A conclusion that only says to use best practices

## AI pattern lexicon

### English patterns

```text
essentially
it's important to note
in conclusion
at the end of the day
a myriad of
navigate the landscape
unlock the potential
in today's fast-paced world
game-changer
deep dive
leverage
synergy
holistic approach
```

### Russian patterns

```text
в конечном итоге
стоит отметить
на самом деле
важно понимать
ключевой момент
безусловно
в целом и общем
не лишним будет
нельзя не отметить
это позволяет
данный подход
```

## When to use this file

| Content type | Criteria set |
|--------------|--------------|
| Short quotes, short comments, 1-5 sentence fragments | Use `quote-criteria.md` |
| Long-form articles and blog posts | Use this file |
| Product descriptions | Use this file and pay extra attention to promotional intent |
| Technical documentation | Use this file, but go easier on personal-accountability criteria when the content is still specific and testable |
