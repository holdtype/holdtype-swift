#!/usr/bin/env python3
"""Heuristic text linter for the de-ai-writing skill."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable


@dataclass
class Match:
    line: int | None
    excerpt: str


@dataclass
class Issue:
    code: str
    title: str
    severity: str
    points: int
    message: str
    suggestion: str
    matches: list[Match] = field(default_factory=list)


WORD_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9]+(?:[-'][A-Za-zА-Яа-яЁё0-9]+)?")
METRIC_RE = re.compile(
    r"\b\d+(?:[.,]\d+)?\s*(?:%|минут(?:а|ы)?|час(?:а|ов)?|секунд(?:а|ы)?|"
    r"дн(?:я|ей|ь)|недел(?:я|и|ь)|месяц(?:а|ев)?|год(?:а|ов)?|"
    r"руб(?:ль|ля|лей)?|₽|доллар(?:а|ов)?|usd|eur|€|x|раз(?:а)?|"
    r"человек(?:а|ов)?|пользовател(?:я|ей)|участник(?:а|ов)?)\b",
    re.IGNORECASE,
)
SENTENCE_END_RE = re.compile(r"(?<=[.!?…])\s+")
PARAGRAPH_SPLIT_RE = re.compile(r"\n\s*\n+")


CHECKS = [
    {
        "code": "symbolic-importance",
        "title": "Inflated importance language",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bиграет (?:важную|значительную|ключевую) роль\b",
            r"\bсимволизиру(?:ет|ют|ющий|ющая)\b",
            r"\bслужит напоминанием\b",
            r"\bподч[её]ркива(?:ет|ют) (?:его|е[её]|их )?важность\b",
            r"\bповоротн(?:ый|ая) момент\b",
            r"\bнеизгладим(?:ый|ая) след\b",
            r"\bsymboli[sz]e(?:s|d)?\b",
            r"\bplays? a (?:vital|key|critical|major) role\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The text leans on significance-signaling language instead of concrete effect.",
        "suggestion": "Replace symbolic importance with a factual result, mechanism, or scoped claim.",
    },
    {
        "code": "vague-authority",
        "title": "Vague authority wrapper",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bпо словам экспертов\b",
            r"\bнекоторые критики утверждают\b",
            r"\bотраслевые отч[её]ты\b",
            r"\bэксперты рекомендуют\b",
            r"\bprofessionals choose\b",
            r"\bexperts (?:say|claim|recommend)\b",
            r"\bsome critics (?:say|argue|claim)\b",
            r"\bindustry reports\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The claim is routed through a blurry source instead of a named, checkable one.",
        "suggestion": "Name the source directly or remove the authority wrapper.",
    },
    {
        "code": "promotional-positivity",
        "title": "Promotional or over-positive wording",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bуникальн(?:ый|ая|ое|ые)\b",
            r"\bинновационн(?:ый|ая|ое|ые)\b",
            r"\bреволюционн(?:ый|ая|ое|ые)\b",
            r"\bпрорывн(?:ой|ая|ое|ые)\b",
            r"\bвдохновляющ(?:ий|ая|ее|ие)\b",
            r"\bэффективн(?:ый|ая|ое|ые)\b",
            r"\bgame-changer\b",
            r"\btransformative\b",
            r"\binnovative\b",
            r"\brevolutionary\b",
            r"\bhighly effective\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The text uses praise words that imply proof without showing it.",
        "suggestion": "Remove the praise word or replace it with a concrete claim the source can support.",
    },
    {
        "code": "didactic-scaffolding",
        "title": "Didactic or editorial scaffolding",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bниже представлен\b",
            r"\bв заключени[ие]\b",
            r"\bподводя итог\b",
            r"\bстоит отметить\b",
            r"\bважно понимать\b",
            r"\bin conclusion\b",
            r"\bit'?s important to note\b",
            r"\bbelow is a (?:detailed )?overview\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The text announces or stages the answer instead of just saying it.",
        "suggestion": "Delete the meta-introduction and lead with the actual claim.",
    },
    {
        "code": "ai-disclaimer",
        "title": "Chat-style disclaimer",
        "severity": "warning",
        "points": 3,
        "patterns": [
            r"\bпо состоянию на мо[её] последнее обновление знаний\b",
            r"\bу меня нет конкретной информации\b",
            r"\bкак языковая модель\b",
            r"\bas of my last knowledge update\b",
            r"\bi don'?t have (?:specific|current) information\b",
            r"\bas an ai language model\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The text includes a chat-assistant disclaimer that does not belong in polished prose.",
        "suggestion": "Delete the disclaimer and keep only source-backed content.",
    },
    {
        "code": "dialogue-imitation",
        "title": "Templated dialogue or salutation",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bуважаемые\b",
            r"\bдорогие\b",
            r"\bнадеюсь, это сообщение застанет вас\b",
            r"\bтема:\b",
            r"\bdear (?:editors|team|reader|all)\b",
            r"\bi hope this message finds you well\b",
            r"\bsubject:\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The prose is staged as a canned dialogue rather than direct content.",
        "suggestion": "Collapse the template and keep only the substantive content.",
    },
    {
        "code": "rhetorical-question",
        "title": "Rhetorical landing-page opener",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bузна[её]шь\?",
            r"\bзнакомо\?",
            r"\bустали от\b",
            r"\bа что, если\b",
            r"\bпредставь\b",
            r"\bпора\b",
            r"\bхватит\b",
            r"\bsound familiar\?",
            r"\bwhat if\b",
            r"\bimagine\b",
        ],
        "modes": {"landing"},
        "message": "The copy relies on a manipulative opener instead of a useful statement.",
        "suggestion": "Replace the opener with a direct claim about the audience, mechanism, or result.",
    },
    {
        "code": "intimate-second-person",
        "title": "Too intimate second-person voice",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bты\b",
            r"\bтебя\b",
            r"\bтвой\b",
            r"\bсидишь\b",
            r"\bлистаешь\b",
            r"\byou\b",
            r"\byour\b",
        ],
        "modes": {"landing"},
        "message": "The landing-page copy slips into intimate second-person narration.",
        "suggestion": "Prefer third person by default or use neutral second person only where the block genuinely calls for it.",
    },
    {
        "code": "urgency-manipulation",
        "title": "Urgency manipulation",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\bтолько сегодня\b",
            r"\bосталось \d+\b",
            r"\bпоследн(?:ий|ие|яя)\b",
            r"\blimited time\b",
            r"\bonly today\b",
            r"\bonly \d+ left\b",
        ],
        "modes": {"landing"},
        "message": "The copy uses urgency cues that need real dates or limits to be credible.",
        "suggestion": "Keep only urgency backed by a real date, inventory limit, or event constraint.",
    },
    {
        "code": "weak-modifier",
        "title": "Weak modifier without specifics",
        "severity": "info",
        "points": 1,
        "patterns": [
            r"\bочень\b",
            r"\bкрайне\b",
            r"\bневероятно\b",
            r"\bпотрясающе\b",
            r"\bпросто\b",
            r"\bлегко\b",
            r"\bбыстро\b",
            r"\bvery\b",
            r"\bextremely\b",
            r"\bsimply\b",
            r"\beasily\b",
            r"\bquickly\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The sentence leans on modifier words that often need a number, unit, or example behind them.",
        "suggestion": "Replace the modifier with a concrete measure, example, or narrower claim.",
    },
    {
        "code": "listicle-heading",
        "title": "Listicle framing",
        "severity": "warning",
        "points": 2,
        "patterns": [
            r"\b(?:топ-?\d+|\d+\s+способ(?:ов|а)?|\d+\s+шаг(?:ов|а)?)\b",
            r"\b(?:top-?\d+|\d+\s+ways|\d+\s+steps)\b",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The text falls into listicle framing, which often correlates with padded structure.",
        "suggestion": "Keep only the items that carry distinct information and rename the section more concretely.",
    },
    {
        "code": "markdown-bullet-headings",
        "title": "Bullet list with mini-headings",
        "severity": "info",
        "points": 1,
        "patterns": [
            r"(?m)^\s*(?:[-*+]|\d+[.)])\s+\*\*[^*]{2,80}\*\*:",
        ],
        "modes": {"general", "article", "landing"},
        "message": "The structure uses templated bullet mini-headings that often read like AI formatting.",
        "suggestion": "Either keep a plain list or turn the point into a regular sentence.",
    },
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run heuristic text checks for the de-ai-writing skill."
    )
    parser.add_argument("path", nargs="?", help="Optional path to the text file. Reads stdin when omitted.")
    parser.add_argument(
        "--mode",
        choices=("general", "article", "landing"),
        default="general",
        help="Check profile tuned for general prose, long-form articles, or landing-page copy.",
    )
    parser.add_argument(
        "--format",
        choices=("markdown", "json"),
        default="markdown",
        help="Output format.",
    )
    parser.add_argument(
        "--max-issues",
        type=int,
        default=12,
        help="Maximum number of issues to print after ranking.",
    )
    return parser.parse_args()


def read_text(path_arg: str | None) -> tuple[str, str]:
    if path_arg:
        path = Path(path_arg)
        return path.read_text(encoding="utf-8"), str(path)
    if sys.stdin.isatty():
        raise SystemExit("Provide a file path or pipe text via stdin.")
    return sys.stdin.read(), "<stdin>"


def word_count(text: str) -> int:
    return len(WORD_RE.findall(text))


def line_number(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def trim_excerpt(excerpt: str, limit: int = 140) -> str:
    cleaned = " ".join(excerpt.strip().split())
    if len(cleaned) <= limit:
        return cleaned
    return cleaned[: limit - 3].rstrip() + "..."


def iter_sentences(text: str) -> Iterable[tuple[str, int]]:
    start = 0
    for match in SENTENCE_END_RE.finditer(text):
        end = match.start()
        sentence = text[start:end].strip()
        if sentence:
            yield sentence, start
        start = match.end()
    tail = text[start:].strip()
    if tail:
        yield tail, start


def iter_paragraphs(text: str) -> list[tuple[str, int, int]]:
    paragraphs: list[tuple[str, int, int]] = []
    last = 0
    for match in PARAGRAPH_SPLIT_RE.finditer(text):
        paragraph = text[last:match.start()].strip()
        if paragraph:
            paragraphs.append((paragraph, last, line_number(text, last)))
        last = match.end()
    tail = text[last:].strip()
    if tail:
        paragraphs.append((tail, last, line_number(text, last)))
    return paragraphs


def scan_pattern_checks(text: str, mode: str) -> list[Issue]:
    issues: list[Issue] = []
    for check in CHECKS:
        if mode not in check["modes"]:
            continue
        matches: list[Match] = []
        count = 0
        for raw_pattern in check["patterns"]:
            for found in re.finditer(raw_pattern, text, re.IGNORECASE):
                count += 1
                if len(matches) < 3:
                    matches.append(
                        Match(
                            line=line_number(text, found.start()),
                            excerpt=trim_excerpt(found.group(0)),
                        )
                    )
        if count:
            points = check["points"] + min(count - 1, 2)
            issues.append(
                Issue(
                    code=check["code"],
                    title=check["title"],
                    severity=check["severity"],
                    points=points,
                    message=f"{check['message']} Found {count} match(es).",
                    suggestion=check["suggestion"],
                    matches=matches,
                )
            )
    return issues


def check_parallelisms(text: str) -> list[Issue]:
    patterns = [
        r"\bне только\b.{0,80}\bно (?:и|также)\b",
        r"\bэто не просто\b.{0,80}\bэто\b",
        r"\bnot only\b.{0,80}\bbut also\b",
        r"\bthis is not just\b.{0,80}\bit is\b",
    ]
    matches: list[Match] = []
    count = 0
    for pattern in patterns:
        for found in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
            count += 1
            if len(matches) < 3:
                matches.append(
                    Match(line=line_number(text, found.start()), excerpt=trim_excerpt(found.group(0)))
                )
    if not count:
        return []
    return [
        Issue(
            code="parallelism",
            title="Parallel emphasis pattern",
            severity="warning",
            points=2 + min(count - 1, 2),
            message=f"The text uses emphasis parallelisms that often read as staged or overly polished. Found {count} match(es).",
            suggestion="Flatten the construction and keep the informational part.",
            matches=matches,
        )
    ]


def check_rule_of_three(text: str) -> list[Issue]:
    pattern = re.compile(
        r"\b(?:[A-Za-zА-Яа-яЁё-]{3,}\s*,\s*){2}(?:и|and)\s+[A-Za-zА-Яа-яЁё-]{3,}\b",
        re.IGNORECASE,
    )
    matches: list[Match] = []
    count = 0
    for found in pattern.finditer(text):
        count += 1
        if len(matches) < 3:
            matches.append(
                Match(line=line_number(text, found.start()), excerpt=trim_excerpt(found.group(0)))
            )
    if not count:
        return []
    return [
        Issue(
            code="rule-of-three",
            title="Rule-of-three filler rhythm",
            severity="info",
            points=1 + min(count - 1, 2),
            message=f"The text leans on three-part phrasing, which can fake completeness when overused. Found {count} match(es).",
            suggestion="Keep the strongest one or two elements and cut the decorative third item.",
            matches=matches,
        )
    ]


def check_long_sentences(text: str, mode: str) -> list[Issue]:
    threshold = 28 if mode == "landing" else 36 if mode == "article" else 32
    long_sentences: list[Match] = []
    counts: list[int] = []
    for sentence, index in iter_sentences(text):
        count = word_count(sentence)
        if count > threshold:
            counts.append(count)
            if len(long_sentences) < 3:
                long_sentences.append(
                    Match(line=line_number(text, index), excerpt=trim_excerpt(sentence))
                )
    if not counts:
        return []
    return [
        Issue(
            code="long-sentences",
            title="Overbuilt sentence length",
            severity="info",
            points=min(3, len(counts)),
            message=(
                f"Found {len(counts)} sentence(s) over the {threshold}-word threshold. "
                f"Longest example: {max(counts)} words."
            ),
            suggestion="Split the sentence or keep only the clause with the actual claim.",
            matches=long_sentences,
        )
    ]


def check_dash_overuse(text: str) -> list[Issue]:
    dash_count = text.count("—")
    sentence_total = max(1, sum(1 for _ in iter_sentences(text)))
    if dash_count < 4 or dash_count / sentence_total < 0.25:
        return []
    return [
        Issue(
            code="dash-overuse",
            title="Long-dash overuse",
            severity="info",
            points=min(3, dash_count // 2),
            message=f"Found {dash_count} em dashes across {sentence_total} sentence(s).",
            suggestion="Replace some dashes with commas, parentheses, or simpler sentence structure.",
            matches=[],
        )
    ]


def check_metric_repetition(text: str, mode: str) -> list[Issue]:
    if mode == "general":
        return []
    registry: dict[str, list[int]] = defaultdict(list)
    for paragraph, _, line in iter_paragraphs(text):
        metrics = {match.group(0).lower() for match in METRIC_RE.finditer(paragraph)}
        for metric in metrics:
            registry[metric].append(line)
    duplicates = {metric: lines for metric, lines in registry.items() if len(lines) > 1}
    if not duplicates:
        return []
    ranked = sorted(duplicates.items(), key=lambda item: (-len(item[1]), item[0]))[:4]
    matches = [Match(line=lines[0], excerpt=f"{metric} -> lines {', '.join(map(str, lines))}") for metric, lines in ranked]
    return [
        Issue(
            code="metric-repetition",
            title="Repeated metric across blocks",
            severity="warning" if mode == "landing" else "info",
            points=min(4, sum(len(lines) - 1 for lines in duplicates.values())),
            message=f"Found {len(duplicates)} repeated metric phrase(s) across paragraphs or blocks.",
            suggestion="Keep each metric in the block where it does the most work and remove the repeats elsewhere.",
            matches=matches,
        )
    ]


def analyze(text: str, mode: str) -> dict:
    issues: list[Issue] = []
    issues.extend(scan_pattern_checks(text, mode))
    issues.extend(check_parallelisms(text))
    issues.extend(check_rule_of_three(text))
    issues.extend(check_long_sentences(text, mode))
    issues.extend(check_dash_overuse(text))
    issues.extend(check_metric_repetition(text, mode))
    issues.sort(key=lambda issue: (-issue.points, issue.severity, issue.code))

    score = sum(issue.points for issue in issues)
    if score <= 3:
        verdict = "clean"
    elif score <= 7:
        verdict = "light-review"
    elif score <= 12:
        verdict = "needs-review"
    else:
        verdict = "needs-rewrite"

    severity_counts = Counter(issue.severity for issue in issues)
    return {
        "mode": mode,
        "verdict": verdict,
        "score": score,
        "word_count": word_count(text),
        "issue_count": len(issues),
        "severity_counts": dict(severity_counts),
        "issues": [asdict(issue) for issue in issues],
    }


def render_markdown(report: dict, source: str, max_issues: int) -> str:
    lines = [
        "# De-Eggify Lint Report",
        "",
        f"- Source: `{source}`",
        f"- Mode: `{report['mode']}`",
        f"- Verdict: `{report['verdict']}`",
        f"- Score: `{report['score']}`",
        f"- Words: `{report['word_count']}`",
        f"- Issues: `{report['issue_count']}`",
    ]
    severity_counts = report["severity_counts"]
    if severity_counts:
        parts = [f"{key}={severity_counts[key]}" for key in sorted(severity_counts)]
        lines.append(f"- Severities: {', '.join(parts)}")
    lines.append("")

    shown = report["issues"][:max_issues]
    if not shown:
        lines.append("No issues found by the current heuristic profile.")
        return "\n".join(lines) + "\n"

    lines.append("## Top Issues")
    lines.append("")
    for issue in shown:
        lines.append(
            f"### [{issue['severity']}] {issue['title']} (`{issue['code']}`, +{issue['points']})"
        )
        lines.append("")
        lines.append(issue["message"])
        lines.append("")
        lines.append(f"Suggestion: {issue['suggestion']}")
        if issue["matches"]:
            lines.append("")
            lines.append("Matches:")
            for match in issue["matches"]:
                if match["line"] is None:
                    lines.append(f"- `{match['excerpt']}`")
                else:
                    lines.append(f"- line {match['line']}: `{match['excerpt']}`")
        lines.append("")

    hidden = report["issue_count"] - len(shown)
    if hidden > 0:
        lines.append(f"_Omitted {hidden} lower-ranked issue(s)._")
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    text, source = read_text(args.path)
    report = analyze(text, args.mode)
    if args.format == "json":
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return
    print(render_markdown(report, source, args.max_issues))


if __name__ == "__main__":
    main()
