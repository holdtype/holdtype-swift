#!/usr/bin/env python3
"""Normalize typography for informal social-text output."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


QUOTE_TRANSLATION = str.maketrans(
    {
        "«": '"',
        "»": '"',
        "“": '"',
        "”": '"',
        "„": '"',
        "‟": '"',
        "‘": "'",
        "’": "'",
        "‚": "'",
        "‛": "'",
        "`": "'",
        "´": "'",
        "…": "...",
        "\u00A0": " ",
        "\u202F": " ",
        "\u2009": " ",
        "\u2060": "",
    }
)

DASH_CHARS = "\u2012\u2013\u2014\u2015\u2212\u2011"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert typographic punctuation to a plainer informal style."
    )
    parser.add_argument("path", nargs="?", help="Optional input file path. Reads stdin when omitted.")
    parser.add_argument(
        "--in-place",
        action="store_true",
        help="Overwrite the input file instead of printing to stdout.",
    )
    return parser.parse_args()


def read_text(path_arg: str | None) -> tuple[str, Path | None]:
    if path_arg:
        path = Path(path_arg)
        return path.read_text(encoding="utf-8"), path
    if sys.stdin.isatty():
        raise SystemExit("Provide a file path or pipe text via stdin.")
    return sys.stdin.read(), None


def normalize_dashes(text: str) -> str:
    text = re.sub(rf"(?<=\d)\s*[{DASH_CHARS}]\s*(?=\d)", "-", text)
    text = re.sub(rf"(?m)^\s*[{DASH_CHARS}]\s*", "- ", text)
    text = re.sub(rf"(?<=\S)\s*[{DASH_CHARS}]\s*(?=\S)", " - ", text)
    return re.sub(rf"[{DASH_CHARS}]", "-", text)


def normalize_spacing(text: str) -> str:
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r" *\n", "\n", text)
    return re.sub(r"\n{3,}", "\n\n", text)


def normalize_text(text: str) -> str:
    text = text.translate(QUOTE_TRANSLATION)
    text = normalize_dashes(text)
    return normalize_spacing(text)


def main() -> None:
    args = parse_args()
    text, path = read_text(args.path)
    normalized = normalize_text(text)

    if args.in_place:
        if path is None:
            raise SystemExit("--in-place requires a file path.")
        path.write_text(normalized, encoding="utf-8")
        return

    sys.stdout.write(normalized)


if __name__ == "__main__":
    main()
