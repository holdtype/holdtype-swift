---
name: de-ai-writing
description: Rewrite Russian or English prose so it sounds less AI-ish, less generic, and less bot-written while preserving meaning and not inventing facts. Use when the user pastes copy, notes, a social post, article, landing-page text, hero block, pricing block, FAQ, or other prose and asks to make it sound more human, more grounded, less slop, less generic, less corporate, less manipulative, less ИИ-шно, or wants a brief slop diagnosis, a safer rewrite, or informal non-typographic post-processing for social text.
---

# De-AI Writing

## Overview

Rewrite prose to remove high-signal AI patterns without sanding off the core meaning.
Default to rewrite-only output.
If the user invokes the skill and pastes text without further instruction, assume they want the best ready-to-use version in the same language and register.
For post-like text, bias toward a strong social-post version suitable for Facebook and similar feeds.

## Workflow

1. Detect the request mode.
   - Return only a rewrite if the user asks to rewrite.
   - Return only a rewrite if the user invokes the skill and pastes text without an explicit prompt.
   - Return only a diagnosis if the user asks to audit, score, or critique.
   - Treat extra instructions such as "make it meaner," "for Facebook," "shorter," or "more technical" as constraints on the rewrite, not as a request for explanation.
   - Return a brief diagnosis plus one rewrite only if the user explicitly asks for analysis or seems unsure what is wrong.
2. Detect the text type.
   - Read [references/quote-criteria.md](references/quote-criteria.md) for short text up to 5 sentences.
   - Read [references/full-criteria.md](references/full-criteria.md) for articles, long posts, and other long-form prose.
   - Read [references/landing-infostyle.md](references/landing-infostyle.md) for landing pages, hero blocks, pricing, FAQ, value props, and other commercial page copy.
   - Read [references/wiki-signals.md](references/wiki-signals.md) for portable AI-text markers distilled from the Wikipedia essay without the Wikipedia-specific noise.
3. Diagnose quickly.
   - Surface only the 3-6 highest-signal problems.
   - Prefer problems such as generic claims, fake certainty, missing specifics, template structure, filler transitions, sterile conclusions, and lexical repetition.
   - Mirror the user's framing. Use "AI-ish," "generic," "corporate," or "ИИ-шно" as appropriate instead of forcing the term "slop."
   - Do not enumerate every criterion unless the user asks for scoring.
4. Rewrite.
   - Keep the original language unless the user asks to translate.
   - Preserve claims, stance, audience, and technical constraints.
   - Prefer concrete verbs, concrete nouns, and shorter causal chains.
   - Cut filler openings, placeholder transitions, and interchangeable bullets.
   - Keep some asymmetry, friction, or hesitation when it makes the prose sound more human.
5. Run a safety pass.
   - Do not invent facts, metrics, dates, links, product outcomes, personal experience, or named examples.
   - Replace unjustified certainty with scoped language.
   - If the source lacks specifics, leave a modest version or flag the missing slots for real author input.
6. Normalize typography when the target is informal.
   - For Facebook, Telegram, X, casual notes, or other informal social text, run [scripts/normalize_informal_text.py](scripts/normalize_informal_text.py) after the rewrite.
   - Prefer plain ASCII-friendly punctuation over editorial typography in informal mode.
   - Use this step only when the user wants casual presentation. Do not force it on polished articles or landing pages.

## Linter

Use the bundled Python linter when the text is long enough that a repeatable machine pass adds value.

- Prefer the linter for articles, long posts, and landing pages with multiple blocks.
- Skip it for very short snippets unless the user explicitly asks for a score or report.
- Treat the linter as a heuristic report, not as a detector or final verdict.

Commands:

```bash
python3 scripts/lint_text.py --mode article --format markdown path/to/text.md
python3 scripts/lint_text.py --mode landing --format markdown path/to/landing.md
cat draft.txt | python3 scripts/lint_text.py --mode general --format json
```

Interpretation:

- Use the report to find stable, machine-checkable problems first.
- Rewrite only the issues that materially improve clarity, credibility, and tone.
- After a substantial rewrite, re-run the linter on the new version for long-form and landing-page text.

## Informal Typography

Use the bundled postprocessor when the user wants informal formatting for social posts or casual writing.

- Replace long dashes with plain hyphens.
- Replace typographic quotes with straight quotes.
- Replace typographic apostrophes with plain apostrophes.
- Replace the single-character ellipsis with `...`.
- Normalize non-breaking spaces back to regular spaces.

Commands:

```bash
python3 scripts/normalize_informal_text.py post.txt
cat draft.txt | python3 scripts/normalize_informal_text.py
python3 scripts/normalize_informal_text.py --in-place post.txt
```

Use this as the last pass after the rewrite.

## Rewrite Rules

- Preserve meaning before polish.
- Remove phrases that only signal importance instead of proving it.
- Replace abstract praise with a concrete effect when the source supports one.
- Delete decorative metaphors unless they explain something real.
- Keep terminology, product names, versions, and edge-case constraints intact.
- Prefer one sharp sentence over two sentences that restate each other.
- Break list symmetry when items feel templated or interchangeable.
- Keep edits light when the source is already clean.

## Landing Pages

Use this mode for commercial page copy such as hero blocks, feature sections, pricing, CTA areas, and FAQ.

- Prioritize facts, respect, and utility over emotional manipulation.
- Ban rhetorical questions, fake empathy, urgency theater, and vague authority.
- Ban empty praise, buzzwords, and weak modifiers unless the text provides specifics.
- Prefer third person by default.
- Allow second person mainly in FAQ answers and pricing explanations.
- Require numbers with units and sources when the copy makes quantitative claims.
- Keep one fact or number in one block; do not repeat the same metric across the page unless the user explicitly wants repetition.
- For landing pages, prefer grounded capability claims over identity theater or lifestyle storytelling.

## Output Shapes

### Default

Use this when the user invokes the skill with source text and no extra instruction, or simply asks to "fix" or "rewrite" it.

`Rewrite`
- Return one improved version in the same language.
- Return only the rewritten text.
- Do not add notes, diagnosis, framing, or alternatives unless the user asks.
- For social-post-like text, prefer the strongest Facebook-ready version by default.

`Author-input gaps`
- Add this only when missing real specifics materially limit the rewrite.
- Ask for concrete inputs such as dates, examples, numbers, tools, places, failures, or tradeoffs.

### Analysis on request

- Return diagnosis only when the user asks for diagnosis, scoring, critique, or explanation.
- Keep it brief and subordinate to the rewrite unless the user asks for analysis only.

### Optional variants

- Offer `conservative` and `sharper` versions only if the user asks for options.
- Offer a `line edit` version if the user needs structure preserved closely.

## Reference Files

- Use [references/quote-criteria.md](references/quote-criteria.md) for fast scoring of short text.
- Use [references/full-criteria.md](references/full-criteria.md) for long-form diagnosis.
- Use [references/landing-infostyle.md](references/landing-infostyle.md) for landing-page copy and other conversion-oriented blocks.
- Use [references/wiki-signals.md](references/wiki-signals.md) for the distilled Wikipedia-derived markers that transfer well beyond Wikipedia itself.
- Treat both references as heuristics, not as permission to flatten a distinctive human voice.
